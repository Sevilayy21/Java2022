package kodlama.io.languageDay4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LanguageDay4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
